/*Rob Hughes
 CPSC2310 Lab11
 rbhughe
 Section 5
 */

include <stdio.h>
int main(){
	int min=0;
	int max=10;
	for(int i=0; i<=max; i++){
		printf("%d", i);
	}
	printf("\n");
	return 0;
}
