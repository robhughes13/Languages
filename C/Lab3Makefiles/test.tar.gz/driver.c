#include <stdio.h>
#include "src/functions.h"
int main(int argc, char* argv[])
{
    printf("%d\n",sum(5, 10));
    return 0;
}
