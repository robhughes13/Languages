/*Rob Hughes
 CPSC2310 Lab8
 rbhughe
 Section 5
 */

#include "functions.h"


int main()
{
    printf("%d\n", isArithmetic());
    return 0;
}
