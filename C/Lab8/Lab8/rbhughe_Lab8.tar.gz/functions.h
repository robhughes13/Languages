/*Rob Hughes
 CPSC2310 Lab8
 rbhughe
 Section 5
 */

#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <stdio.h>

int isArithmetic();
int isOddOne(unsigned);

#endif
