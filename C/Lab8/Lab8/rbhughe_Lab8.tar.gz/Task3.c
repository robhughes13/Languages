/*Rob Hughes
 CPSC2310 Lab8
 rbhughe
 Section 5
 */

#include "functions.h"

int main()
{

    printf("%d\n", isOddOne(128));
    printf("%d\n", isOddOne(64));

    return 0;
}


